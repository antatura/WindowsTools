Fliqlo Screensaver Version 1.3.3 for Windows ReadMe
*updated on May 31, 2019

INSTALLATION
This software requires Adobe Flash Player Plug-in, which needs to be installed on your computer in advance, then double-click the icon labelled "Fliqlo Setup". The Adobe Flash Player is available from https://get.adobe.com/flashplayer/.

UNINSTALLATION
In Windows 7 or later, you can uninstall from "Apps & features (or Program and Features)".

TERMS OF USE
This software is intended for your personal desktop use only. No portion of the software, including the other files in "Fliqlo 1.3.3" folder or zip archive, may be redistributed, sold, renamed, converted, or made available for download from websites other than fliqlo.com. Instead, please provide a link to https://fliqlo.com/ if you wish to share the software.

DISCLAIMER
This software is provided to you free of charge. The author gives no warranty in relation to these softwares, and you use them at your own risk. By using or installing the software, you agree to be bound by the terms of this agreement. The author will not be liable for any damage to your system, any loss or corruption of any data or software, or any other loss or damage that you may suffer as a result of downloading or using the software, whether it results from the author's negligence or in any other way.

DONATION
If you want to make a donation to support the further development of this software, it is highly appreciated. To donate,  double-click the internet shortcut labelled "Donate with PayPall" in "Fliqlo 1.3.3" folder, or visit the author's PayPal.me page (https://www.paypal.me/yjadc/). You may then enter any amount you wish, and PayPal.me will securely do the rest. Thank you for your support!

ABOUT THE AUTHOR
Yuji Adachi
Freelance Web/UI designer, living in Tokyo, Japan

SUPPORT
Website: https://fliqlo.com/
Email: info@9031.com

© 2011 9031